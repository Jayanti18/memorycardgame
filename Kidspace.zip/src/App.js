import React, { Component } from 'react';
import './App.css';
import Navigation from './components/Navigation';
import MemoryGame from './components/MemoryGame';

import {BrowserRouter as Router} from 'react-router-dom';
import Route from 'react-router-dom/Route';
class App extends Component {
  render() {
    return (
      <Router>
        <div>
        <Route path="/" render={
         ()=>{
           return(<Navigation />)
         }
       }/>
       <Route path="/ClickeyGame" render={
         ()=>{
           return(
             
            <MemoryGame/>
          
           )
         }
       }/>
        </div>
       
       
    
      </Router>
     
    );
  }
}


export default App;
